import SwiftUI
import AVFAudio

struct situationThree: View{
    var situationThree = "When you took the right turn and continued ahead you take a forced right turn.In front of you see a left turn a little ahead of you, a right turn a farther away from you, and a path ahead of you."
    var firstDecision = "A.) You:Take the left turn."
    var secondDecision = "B.) You:You take the right turn farther away from you."
    var thirdDecision = "C.)You take the path ahead of you."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyThree = ""
    var body: some View{
        //NavigationView{
            ZStack{
                Image("You")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
                VStack{
                    Text(situationThree)
                        .foregroundColor(.white)
                        .font(.system(size:35))
                        .padding()
                    NavigationLink(destination:Map()){
                        Text("Map")
                            .font(.title)
                            .foregroundColor(.white)
                            .underline(true, color: Color.white)
                    }
                    //Add a new source folder to send other situation
                    NavigationLink(destination: situationThreeFirst()){
                        Text(firstDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: situationThreeSecond()){
                        Text(secondDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: situationFour()){
                        Text(thirdDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    //}
                }
            }
        }
            .onAppear(perform: {
                let soundName = "backgroundSound"
                guard let soundFile = NSDataAsset(name: soundName ) else {
                    print(" Could not read file named \(soundName)")
                    return
                }
                do{
                    audioPlayer = try AVAudioPlayer(data: soundFile.data)
                    audioPlayer.play()
                } catch {
                    print("ERROR: \(error.localizedDescription) creating audioPlayer.")
                }
            })

    }
}
