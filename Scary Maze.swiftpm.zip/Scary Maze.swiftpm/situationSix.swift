import SwiftUI
import AVFAudio

struct situationSix: View{
    var situationSix = "As you were turning to the right turn your map falls out of your pocket. When you go back and looked up the the monster is 6ft from you. You don't pickup the map and your forced to leave it behind. You take a right then continued running forward then took a left. In front of you appears three paths. One path is on the left near you,the second path is on the right ahead of you, and a third path which had lights at the end of the end.You have suspicion that the lights at the end of the path might be a trap. "
    var firstDecision = "A.) You: Take the left path."
    var secondDecision = "B.) You: Take the right path."
    var thirdDecision = "C.) You: Take the path ahead of you."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storySix = ""
    var body: some View{
        //NavigationView{
        ZStack{
            Image("You")
                .resizable()
                .frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack{
                Text(situationSix)
                    .foregroundColor(.white)
                    .font(.system(size:15))
                    .padding()
                NavigationLink(destination:Map()){
                    Text("Map")
                        .font(.title)
                        .foregroundColor(.white)
                        .underline(true, color: Color.white)
                }
                    //Add a new source folder to send other situation
                    NavigationLink(destination: situationOne()){
                        Text(firstDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: situationTwo()){
                        Text(secondDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: Escape()){
                        Text(thirdDecision)
                            .font(.title)
                        .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)
                }
            }
            
        }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return 
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data) 
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
        })
    }
}
