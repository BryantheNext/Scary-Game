import SwiftUI
import AVFAudio

struct Map: View {
    @State private var audioPlayer: AVAudioPlayer!
    var body: some View{
        //NavigationView{
            VStack{
                HStack{
                    Text("You think your at the center of the maze.")
                        .foregroundColor(.white)
                            }
                Image("Maze map")
                    .resizable()
                    .frame(width:500,height:500,alignment:.center)
            }
            .frame(maxWidth:.infinity,maxHeight:.infinity)
            .background(.black)
       // }
            .onAppear(perform: {
                let soundName = "backgroundSound"
                guard let soundFile = NSDataAsset(name: soundName ) else {
                    print(" Could not read file named \(soundName)")
                    return
                }
                do{
                    audioPlayer = try AVAudioPlayer(data: soundFile.data)
                    audioPlayer.play()
                } catch {
                    print("ERROR: \(error.localizedDescription) creating audioPlayer.")
                }
            })
    } 
}

