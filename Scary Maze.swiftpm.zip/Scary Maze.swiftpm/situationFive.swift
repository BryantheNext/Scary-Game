import SwiftUI
import AVFAudio

struct situationFive: View{
    var situationFive = "When you enter the left path you are encountered with a left and right turn. The left turn when you take a quick gimpse has a long straight path.The right turn has a a straight path also. "
    var firstDecision = "A.)You take the left turn."
    var secondDecision = "B.)You take the right turn."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyFive = ""
    var body: some View{
        //NavigationView{
        ZStack{
            Image("leftTurn")
                .resizable()
                .frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack{
                Text(situationFive)
                    .foregroundColor(.white)
                    .font(.system(size:30))
                    .padding()
                NavigationLink(destination:Map()){
                    Text("Map")
                        .font(.title)
                        .foregroundColor(.white)
                        .underline(true, color: Color.white)
                }
                    NavigationLink(destination: situationOne()){
                        Text(firstDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                }
                        NavigationLink(destination: situationSix()){
                        Text(secondDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                   // }
                }
            }
        }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
        })
    }
}
