import SwiftUI
import AVFAudio

struct Dead: View {
    @State private var audioPlayer: AVAudioPlayer!
    @State var showNext = false
    var body: some View{
        ZStack{
            if showNext {
                Start()
            } else {
                Image("Death Screen")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
            }
                VStack{
                    //Story collects the story and the decisions made to a story of the adventure.
                    //Use a button when pushed shows the whole story(the decisions and the story put together.)
                    // Text(\(story))
                    /*
                     Button{
                     
                     }label:{
                     Text("\(story)")
                     .foregroundColor(.white)
                     }
                     */
                }
            }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5, execute: {
                showNext = true            
            })
            })
    }
}
