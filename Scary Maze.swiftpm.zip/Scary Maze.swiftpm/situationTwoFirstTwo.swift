import SwiftUI
import AVFAudio

struct situationTwoFirstTwo: View{
    var situationTwoFirstTwo = "You take the right path and continue running and take another right turn which you continue running, but you hit a dead end.The monster creeps and..."
    @State private var audioPlayer: AVAudioPlayer!
    @State var showSurprise = false
    @State var showNext = false
    //@State var storyThree = ""
    var body: some View{
        ZStack{
            if showNext {
                Dead()
            } else {
                Image("You")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
            }
                VStack{
                    Text(situationTwoFirstTwo)
                        .foregroundColor(.white)
                }
            }
             .onAppear(perform: {
             let soundName = "backgroundSound"
             guard let soundFile = NSDataAsset(name: soundName ) else {
             print(" Could not read file named \(soundName)")
             return
             }
             do{
             audioPlayer = try AVAudioPlayer(data: soundFile.data)
             audioPlayer.play()
             } catch {
             print("ERROR: \(error.localizedDescription) creating audioPlayer.")
             }
             DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5, execute: {
             showSurprise = true
             
             let nameSound = "jumpScare"
             guard let soundFile = NSDataAsset(name: nameSound ) else {
             print(" Could not read file named \(nameSound)")
             return
             }
             do{
             audioPlayer = try AVAudioPlayer(data: soundFile.data)
             audioPlayer.play()
             } catch {
             print("ERROR: \(error.localizedDescription) creating audioPlayer.")
             }
             })
             DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 10, execute: {
             showNext = true
             showSurprise = false
             })
             })
    }
}
