import SwiftUI

@main
struct MyApp: App {
   // @EnvironmentalObject var name = ""
    
    //@State var story = ""
   // @State var name = ""
    var body: some Scene {
        WindowGroup {
           //Start()
           //Information()
           // Game()
           // situationOne()
            //situationTwo()
           // situationThree()
           // situationFour()
            //situationFive()
            //situationSix()
            //situationThreeFirstOne()
            //situationSecondThree()
            //situationTwoFirstOne()
            //situationSecondTwo
            //situationSecondThreeOne()
            //situationSecondThreeOne()
            //situationSecondThreeOne()
          //Map()
            //Dead()
           //Escape()
        }
    }
}
