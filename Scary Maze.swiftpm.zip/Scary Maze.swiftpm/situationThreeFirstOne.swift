import SwiftUI
import AVFAudio

struct situationThreeFirstOne: View{
    var situationThreeFirstOne = "You take the right path and continue running and take another right turn which you continue running, but you hit a dead end.The monster creeps and..."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyThree = ""
    @State var showSurprise = false
    @State var showNext = false
    var body: some View{
        ZStack{
            if showNext {
                Dead()
                // Text("Next")
                    .border(Color.black)
            } else {
                Image("You")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
                VStack{
                    Text(situationThreeFirstOne)
                        .foregroundColor(.white)
                }
            }
            if showSurprise {
                Image("JumpScreen")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
                
            }
        }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
//            withAnimation(.linear(duration: 0.2).delay(5)) {
//                showSurprise = true
//
//            }
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5, execute: {
                showSurprise = true

                let nameSound = "jumpScare"
                guard let soundFile = NSDataAsset(name: nameSound ) else {
                    print(" Could not read file named \(nameSound)")
                    return
                }
                do{
                    audioPlayer = try AVAudioPlayer(data: soundFile.data)
                    audioPlayer.play()
                } catch {
                    print("ERROR: \(error.localizedDescription) creating audioPlayer.")
                }
            })
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 10, execute: {
                showNext = true
                showSurprise = false
            })
            })
        // DispatchQueue

    }
}


