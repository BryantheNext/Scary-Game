import SwiftUI
import AVFAudio

struct Information: View {
    @State private var audioPlayer: AVAudioPlayer!
    var body: some View {
        ZStack{
            Image("You")
                .resizable()
                .frame(maxWidth:.infinity, maxHeight:.infinity)
            VStack{
                Group {
                    Text("Context:")
                        .foregroundColor(.white)
                    Text("You wake up in a scary corn maze not knowing where you are. You hear footsteps and a breathing near you. You check your pockets and find a map in your pocket and a flashlight you turned on. You check the map and find yourself in ther middle of the maze. You see a unknown creature hiding in the maze. You run away, but they follow you.")
                        .foregroundColor(.white)
                        .padding()
                    Text("Direction:")
                        .foregroundColor(.white)
                    Text("Escape the maze")
                        .foregroundColor(.white)
                        .padding()
                    Text("Tips:")
                        .foregroundColor(.white)
                    Text("Your descisions decides the out come of the game. If your caught in a dead end or back at the beginning you die. You can't go back on your descisions you progress forward, so if misclick or clicked the wrong option you can't go back.")
                        .foregroundColor(.white)
                        .padding()
                    Text("Important Notice")
                        .foregroundColor(.white)
                    Text("Dead ends are any objects in the way of a path and the path ending.")
                        .foregroundColor(.white)
                        .padding()
                    Text("Warnings:")
                        .foregroundColor(.white)
                }
                Text("The game might not be suitable for younger audience.The game includes jumpscares,loud sounds,tense situation, and scary sounds.")
                    .foregroundColor(.white)
                    .padding()
                Text("Have fun, Good Luck!")
                    .foregroundColor(.white)
                    .padding()
                    .padding()
                // NavigationView{
                    NavigationLink(destination: situationOne()){
                        Text("Start Game")
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:100,height:100,alignment:.center)
                            .background(.red)       
                    }
                    Image("Map")
                        .resizable()
                        .frame(width:250,height:250,alignment:.center)
                // }
            }
        }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
        })

    }
}

