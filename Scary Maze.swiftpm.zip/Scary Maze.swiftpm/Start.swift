
import SwiftUI
import AVFAudio

struct Start: View {
    @State var name = ""
    @State private var audioPlayer: AVAudioPlayer!
    var body: some View {
        NavigationView{
        ZStack {
                Image("Scary Game")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
                VStack{
                    Text("Corn Maze")
                        .font(.system(size:100))
                        .foregroundColor(.red)
                        .padding()
                    Text("Enter your name.")
                        .font(.title)
                        .foregroundColor(.red)
                    TextField("",text:$name)
                        .font(.system(size: 25))
                        .foregroundColor(.red)
                        .background(.white)
                        .frame(width:200,height:50,alignment: .center)
                    Text("Welcome to my spooky story, \(name)")
                        .foregroundColor(.red)
                        .font(.body)
                    NavigationLink(destination: Information()){
                        Text("Start")
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 10.0, style: .continuous))
                            .frame(width:150,height:100,alignment:.center)
                            .background(.red)
                    }
                }
            }
        }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
        })

    }
} 

