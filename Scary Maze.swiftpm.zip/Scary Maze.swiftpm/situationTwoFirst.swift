import SwiftUI
import AVFAudio

struct situationTwoFirst: View{
    var situationTwoFirst = "When you take the path left of you see a right turn that leads to another turn and a right turn that leads to a another turn"
    var firstDecision = "A.) You:Take the path left of you.."
    var secondDecision = "B.)You: Take the path right of you."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyThree = ""
    var body: some View{
        //NavigationView{
            ZStack{
                Image("You")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
                VStack{
                    Text(situationTwoFirst)
                        .foregroundColor(.white)
                        .font(.system(size:35))
                        .padding()
                    NavigationLink(destination:Map()){
                        Text("Map")
                            .font(.title)
                            .foregroundColor(.white)
                            .underline(true, color: Color.white)
                    }
                    //Add a new source folder to send other situation
                    NavigationLink(destination: situationTwoFirstOne()){
                        Text(firstDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: situationTwoFirstTwo()){
                        Text(secondDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                }
            }
        }
            .onAppear(perform: {
                let soundName = "backgroundSound"
                guard let soundFile = NSDataAsset(name: soundName ) else {
                    print(" Could not read file named \(soundName)")
                    return
                }
                do{
                    audioPlayer = try AVAudioPlayer(data: soundFile.data)
                    audioPlayer.play()
                } catch {
                    print("ERROR: \(error.localizedDescription) creating audioPlayer.")
                }
            })

    }
}

