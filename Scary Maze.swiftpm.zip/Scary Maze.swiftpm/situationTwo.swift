import SwiftUI
import AVFAudio

struct situationTwo: View{
    var situationTwo = "When you take the path ahead you see a left turn that's to dark to see the end.You see another path if you turned right and continued walking then turned left. And you see another path if you turned right and continued walking passing the left turn."
    var firstDecision = "A.) You: Take the the left turn."
    var secondDecision = "B.) You: Take the right turn then left turn."
    var thirdDecision = "C.) You: Take the right turn then continue walking ahead."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyTwo = ""
    var body: some View{
        //NavigationView{
        ZStack{
            Image("You")
                .resizable()
                .frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack{
                Text(situationTwo)
                    .foregroundColor(.white)
                    .font(.system(size:30))
                    .padding()
                NavigationLink(destination:Map()){
                    Text("Map")
                        .font(.title)
                        .foregroundColor(.white)
                        .underline(true, color: Color.white)
                }
                    //Add a new source folder to send other situation
                    NavigationLink(destination: situationSecondTwo()){
                        Text(firstDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: situationSecondThree()){
                        Text(secondDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                }
                    NavigationLink(destination: situationThree()){
                        Text(thirdDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    //}
                }
            }
        }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
        })
    }
}

