import SwiftUI
import AVFAudio

struct situationSecondThree: View{
    var situationSecondThree = "You take the left turn and you see a left or right."
    var firstDecision = "A.) You:Take the left turn."
    var secondDecision = "B.) You: Take the right turn."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyOne = ""
    var body: some View{
        //NavigationView{
            ZStack{
                Image("You")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
                VStack{
                    Text(situationSecondThree)
                        .foregroundColor(.white)
                        .font(.system(size:25))
                        .padding()
                    NavigationLink(destination:Map()){
                        Text("Map")
                            .font(.title)
                            .foregroundColor(.white)
                            .underline(true, color: Color.white)
                    }
                   // NavigationLink(destination: situationSecondThreeOne()){
                        Text(firstDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: situationSecondThreeTwo()){             Text(secondDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                   // }
                }
            }
            .onAppear(perform: {
                let soundName = "backgroundSound"
                guard let soundFile = NSDataAsset(name: soundName ) else {
                    print(" Could not read file named \(soundName)")
                    return
                }
                do{
                    audioPlayer = try AVAudioPlayer(data: soundFile.data)
                    audioPlayer.play()
                } catch {
                    print("ERROR: \(error.localizedDescription) creating audioPlayer.")
                }
            })

        }
    }
// }
