import SwiftUI
import AVFAudio

struct situationFour: View{
    var situationFour = "When you take the path ahead you're encountered with a left and right turn. When you peer down the right turn you see the path leads to a long dark nothingness.And when you look to the left you see a right turn in the left path if you enter it."
    var firstDecision = "A.)You: Take the left path."
    var secondDecision = "B.)You:Take the right path."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyFour = ""
    var body: some View{
        //NavigationView{
        ZStack{
            Image("You")
                .resizable()
                .frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack{
                Text(situationFour)
                    .foregroundColor(.white)
                    .font(.system(size:25))
                    .padding()
                NavigationLink(destination:Map()){
                    Text("Map")
                        .font(.title)
                        .foregroundColor(.white)
                        .underline(true, color: Color.white)
                }
                    NavigationLink(destination: situationFive()){
                        Text(firstDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    }
                    NavigationLink(destination: situationTwo()){
                        Text(secondDecision)
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:400,height:100,alignment:.center)
                            .background(.red)         
                    //}
                }
            }
        }
        //.onAppear(
          //  SoundManager.instance.playSound(sound: .backgroundSound)
        //)

    }
}
