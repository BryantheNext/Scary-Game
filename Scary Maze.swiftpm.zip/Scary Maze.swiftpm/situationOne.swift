import SwiftUI
import AVFAudio

struct situationOne: View{
    var situationOne = "You start running. You check your map and find yourself facing south on the map. There's a left turn and a path ahead. "
    var firstDecision = "A.) You:Take the path ahead."
    var secondDecision = "B.) You: Take the left path."
    @State private var audioPlayer: AVAudioPlayer!
    //@State var storyOne = ""
    var body: some View{
        //NavigationView{
        VStack{
        ZStack{
            Image("You")
                .resizable()
                .frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack{
                  Text(situationOne)
                    .foregroundColor(.white)
                    .font(.system(size:35))
                    .padding()
                NavigationLink(destination:Map()){
                    Text("Map")
                        .font(.title)
                        .underline(true, color: Color.white)
                        .foregroundColor(.white)
                }
                        VStack{
                            NavigationLink(destination: situationTwo()){
                                Text(firstDecision)
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .clipShape(Rectangle())
                                    .frame(width:400,height:100,alignment:.center)
                                    .background(.red)
                        }
                            NavigationLink(destination: situationTwoFirstTwo()){
                                Text(secondDecision)
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .clipShape(Rectangle())
                                    .frame(width:400,height:100,alignment:.center)
                                    .background(.red)         
                            //}
                        }
                    
                }
                }
            }
        }
        .onAppear(perform: {
            let soundName = "backgroundSound"
            guard let soundFile = NSDataAsset(name: soundName ) else {
                print(" Could not read file named \(soundName)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
        })
        }
    }
