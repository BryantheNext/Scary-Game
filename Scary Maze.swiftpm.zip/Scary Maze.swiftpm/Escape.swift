import SwiftUI
import AVFAudio

struct Escape: View {
    @State private var audioPlayer: AVAudioPlayer!
    var body: some View{
            ZStack {
                Image("Escaped Screen")
                    .resizable()
                    .frame(maxWidth:.infinity,maxHeight:.infinity)
                VStack{
                    /*
                    //Story collects the story and the decisions made to a story of the adventure.
                    //Text(\(story))
                    // Use a button when pushed shows the story(the decisions and the story put together.)
                    Text("You escaped the maze,\(name)")
                        .foregroundColor(.white)
                        .font(.system(size: 100))
                    
                     Button{
                     
                     }label:{
                     Text("\(story)")
                     .foregroundColor(.white)
                     }
                     */
                    Text("You escaped the maze.")
                        .foregroundColor(.white)
                        .font(.largeTitle)
                    NavigationLink(destination:Start()){
                        Text("Play Again!")
                            .font(.title)
                            .foregroundColor(.white)
                            .clipShape(Rectangle())
                            .frame(width:300,height:100,alignment:.center)
                            .background(.red)          
                    }
            }
        }
            .onAppear(perform: {
                let soundName = "Cheering"
                guard let soundFile = NSDataAsset(name: soundName ) else {
                    print(" Could not read file named \(soundName)")
                    return
                }
                do{
                    audioPlayer = try AVAudioPlayer(data: soundFile.data)
                    audioPlayer.play()
                } catch {
                    print("ERROR: \(error.localizedDescription) creating audioPlayer.")
                }
            })
    }
}
