import SwiftUI
import AVFAudio

struct situationThreeSecondTwo: View{
    var situationThreeSecondTwo = "You take the right turn and you continue running and you take a forced right you hit a dead end. The monster creeps up and..."
    @State private var audioPlayer: AVAudioPlayer!
    @State var showSurprise = false
    @State var showNext = false
    //@State var storyOne = ""
    var body: some View{
        ZStack{
            if showNext {
                Dead()
            } else {
            Image("Scary Game")
                .resizable()
                .frame(maxWidth:.infinity,maxHeight:.infinity)
            VStack{
                Text(situationThreeSecondTwo)
                    .foregroundColor(.white)
            }
        }
        if showSurprise {
            Image("JumpScreen")
                .resizable()
                .frame(maxWidth:.infinity,maxHeight:.infinity)
            
        }
    }
    .onAppear(perform: {
        let soundName = "backgroundSound"
        guard let soundFile = NSDataAsset(name: soundName ) else {
            print(" Could not read file named \(soundName)")
            return
        }
        do{
            audioPlayer = try AVAudioPlayer(data: soundFile.data)
            audioPlayer.play()
        } catch {
            print("ERROR: \(error.localizedDescription) creating audioPlayer.")
        }
//            withAnimation(.linear(duration: 0.2).delay(5)) {
//                showSurprise = true
//
//            }
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5, execute: {
            showSurprise = true

            let nameSound = "jumpScare"
            guard let soundFile = NSDataAsset(name: nameSound ) else {
                print(" Could not read file named \(nameSound)")
                return
            }
            do{
                audioPlayer = try AVAudioPlayer(data: soundFile.data)
                audioPlayer.play()
            } catch {
                print("ERROR: \(error.localizedDescription) creating audioPlayer.")
            }
        })
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 10, execute: {
            showNext = true
            showSurprise = false
        })
        })
    // DispatchQueue

}
}
